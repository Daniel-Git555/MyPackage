# MyPackage
This library was included as an example 

# How to install
...